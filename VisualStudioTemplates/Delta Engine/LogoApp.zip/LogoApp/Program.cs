using DeltaEngine.Platforms;
using DeltaEngine.Scenes.UserInterfaces.Graphing;

namespace $safeprojectname$
{
	public class Program : App
	{
		public Program()
		{
			for (int num = 0; num < 50; num++)
				new BouncingLogo();
		}

		public static void Main()
		{
			new Program().Run();
		}
	}
}