using DeltaEngine.Platforms;

namespace $safeprojectname$
{
	internal static class Program
	{
		public static void Main()
		{
			new App().Start<BouncingLogo>(NumberOfBouncingLogos);
		}

		private const int NumberOfBouncingLogos = 100;
	}
}