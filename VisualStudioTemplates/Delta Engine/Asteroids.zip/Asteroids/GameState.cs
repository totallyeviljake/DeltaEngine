namespace $safeprojectname$
{
	public enum GameState
	{
		Menu,
		Playing,
		GameOver,
		Pause
	}
}