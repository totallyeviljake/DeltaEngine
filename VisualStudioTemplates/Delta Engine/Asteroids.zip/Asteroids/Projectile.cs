using DeltaEngine.Core;
using DeltaEngine.Datatypes;
using DeltaEngine.Graphics;
using DeltaEngine.Physics2D;
using DeltaEngine.Rendering.Sprites;

namespace $safeprojectname$
{
	public class Projectile : Sprite
	{
		public Projectile(Point startPosition, float angle) : 
			base(AsteroidsGame.content.Load<Image>("projectile"), Rectangle.FromCenter(startPosition, 
				new Size(.02f)), Color.White)
		{
			Add(new SimplePhysics.Data() {
				Gravity = Point.Zero,
				Velocity = new Point(MathExtensions.Sin(angle) * Constants.ProjectileVelocity, 
					-MathExtensions.Cos(angle) * Constants.ProjectileVelocity)
			});
			Rotation = angle;
			Add<MoveAndDisposeOnBorderCollision>();
			RenderLayer = (int)Constants.RenderLayer.Rockets;
		}
	}
}