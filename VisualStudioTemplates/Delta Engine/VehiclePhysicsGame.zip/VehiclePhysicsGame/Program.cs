using DeltaEngine.Platforms;

namespace $safeprojectname$
{
	public class Program
	{
		public static void Main()
		{
			var app = new App();
			app.Start<$safeprojectname$>();
		}
	}
}