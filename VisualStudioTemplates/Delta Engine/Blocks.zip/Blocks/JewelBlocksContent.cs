using DeltaEngine.Content;

namespace $safeprojectname$
{
	public class JewelBlocksContent : BlocksContent
	{
		public JewelBlocksContent() : base("JewelBlocks_")
		{
		}
	}
}