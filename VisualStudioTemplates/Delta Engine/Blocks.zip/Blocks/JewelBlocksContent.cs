using DeltaEngine.Content;

namespace $safeprojectname$
{
	public class JewelBlocksContent : BlocksContent
	{
		public JewelBlocksContent(ContentLoader content) : base(content, "JewelBlocks_")
		{
		}
	}
}