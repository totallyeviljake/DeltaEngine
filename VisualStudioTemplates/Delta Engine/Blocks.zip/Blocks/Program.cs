using DeltaEngine.Platforms;

namespace $safeprojectname$
{
	internal static class Program
	{
		public static void Main()
		{
			App app = new App();
			app.Start<FruitBlocksContent, Game>();
		}
	}
}