using DeltaEngine.Content;

namespace $safeprojectname$
{
	public class FruitBlocksContent : BlocksContent
	{
		public FruitBlocksContent(ContentLoader content) : base(content, "FruitBlocks_")
		{
			DoBricksSplitInHalfWhenRowFull = true;
		}
	}
}