namespace $safeprojectname$
{
	public class Constants
	{
		public enum DisplayMode
		{
			LandScape,
			Portrait
		}
	}
}