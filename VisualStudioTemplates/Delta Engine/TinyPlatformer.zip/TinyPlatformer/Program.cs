using DeltaEngine.Input;
using DeltaEngine.Platforms;

namespace $safeprojectname$
{
	internal class Program : App
	{
		public Program()
		{
			new Game(Resolve<Map>(), Resolve<InputCommands>());
		}

		public static void Main()
		{
			new Program().Run();
		}
	}
}