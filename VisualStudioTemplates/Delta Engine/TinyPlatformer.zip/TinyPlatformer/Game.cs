using DeltaEngine.Input;

namespace $safeprojectname$
{
	public class Game
	{
		public Game(Map map, InputCommands inputCommands)
		{
			this.map = map;
			gameLogic = new GameLogic(map, inputCommands);
		}

		private Map map;
		private GameLogic gameLogic;
	}
}