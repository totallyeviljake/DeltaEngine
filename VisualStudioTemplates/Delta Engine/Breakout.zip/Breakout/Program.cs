using DeltaEngine.Platforms;
using DeltaEngine.Rendering.ScreenSpaces;

namespace $safeprojectname$
{
	internal static class Program
	{
		public static void Main()
		{
			new App().Start<UI, Background, RelativeScreenSpace>();
		}
	}
}