using DeltaEngine.Core;

namespace $safeprojectname$
{
	public class Game
	{
		public Game(BallInLevel ball, Score score)
		{
			this.ball = ball;
			score.GameOver += ball.Dispose;
			Score = score;
		}

		private readonly BallInLevel ball;

		public Score Score
		{
			get;
			private set;
		}
	}
}