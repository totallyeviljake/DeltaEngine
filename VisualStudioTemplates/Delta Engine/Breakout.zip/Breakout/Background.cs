using DeltaEngine.Content;
using DeltaEngine.Datatypes;
using DeltaEngine.Graphics;
using DeltaEngine.Rendering.Sprites;

namespace $safeprojectname$
{
	public class Background : Sprite
	{
		public Background(ContentLoader content) : base(content.Load<Image>("Background"), 
			Rectangle.One)
		{
			RenderLayer = DefaultRenderLayer;
		}
	}
}