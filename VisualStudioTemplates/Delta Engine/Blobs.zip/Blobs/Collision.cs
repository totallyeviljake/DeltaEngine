using DeltaEngine.Datatypes;

namespace $safeprojectname$
{
	public struct Collision
	{
		public Collision(Point point, Point normal, object @object) : this()
		{
			Point = point;
			Normal = normal;
			Object = @object;
		}

		public Point Point;
		public Point Normal;
		public readonly object Object;
	}
}