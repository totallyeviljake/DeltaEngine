using DeltaEngine.Content;
using DeltaEngine.Datatypes;
using DeltaEngine.Entities;
using DeltaEngine.Input;
using DeltaEngine.Rendering;

namespace $safeprojectname$.Levels
{
	public class Level1 : WalledLevel
	{
		public Level1(EntitySystem entitySystem, ScreenSpace screen, InputCommands input, 
			ContentLoader content) : base(entitySystem, screen, input, content)
		{
			Color = Color.Yellow;
		}

		protected override void PositionPlayer()
		{
			Player.Center = new Point(0.4f, 0.25f);
			Player.Velocity = new Point(0.8f, 0.0f);
			Player.SetDamping(0.85f, 0.06f);
		}

		protected override void PositionCamera()
		{
			camera.LookAt = Point.Half;
			camera.Zoom = 0.9f;
		}

		protected override void AddPlatforms()
		{
			AddPlatform(new Rectangle(0.4f, 0.4f, 0.5f, 0.05f), 135, Color);
			AddPlatform(new Rectangle(0.875f, 0.5f, 0.15f, 0.05f), 0, Color);
			AddPlatform(new Rectangle(0.0f, 0.5f, 0.15f, 0.05f), 0, Color);
		}

		protected override void AddEnemies()
		{
			AddEnemy(new Point(0.05f, 0.32f), 0.04f);
			AddEnemy(new Point(0.9f, 0.35f), 0.04f);
		}

		protected override void AddText()
		{
		}

		protected override void SetupEvents()
		{
		}

		public override void Dispose()
		{
			base.Dispose();
		}
	}
}