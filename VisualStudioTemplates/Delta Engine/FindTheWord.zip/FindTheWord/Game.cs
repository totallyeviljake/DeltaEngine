using DeltaEngine.Datatypes;
using DeltaEngine.Platforms;

namespace $safeprojectname$
{
	public class Game
	{
		public Game(Window window, StartupScreen startScreen, GameScreen gameScreen)
		{
			window.BackgroundColor = Color.Gray;
			window.ViewportPixelSize = new Size(1280, 800);
			this.startScreen = startScreen;
			startScreen.GameStarted += OnStartupScreenGameStarted;
			this.gameScreen = gameScreen;
			gameScreen.Hide();
		}

		private readonly StartupScreen startScreen;
		private readonly GameScreen gameScreen;

		private void OnStartupScreenGameStarted()
		{
			startScreen.FadeOut();
			gameScreen.FadeIn();
		}
	}
}