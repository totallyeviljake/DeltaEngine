namespace $safeprojectname$
{
	public class RabbitHealth
	{
		public float CurrentHealth
		{
			get;
			set;
		}

		public float MaxHealth
		{
			get;
			set;
		}
	}
}