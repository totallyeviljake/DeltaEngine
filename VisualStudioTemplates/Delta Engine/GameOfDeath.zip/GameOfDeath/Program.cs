using DeltaEngine.Input;
using DeltaEngine.Multimedia;
using DeltaEngine.Platforms;
using DeltaEngine.Rendering.ScreenSpaces;

namespace $safeprojectname$
{
	public class Program : App
	{
		public Program()
		{
			var screenSpace = Resolve<ScreenSpace>();
			new Intro();
			new UI(screenSpace, Resolve<SoundDevice>());
			new InputCoordinator(screenSpace.Window, Resolve<InputCommands>(), 
				Resolve<GameCoordinator>());
		}

		private static void Main()
		{
			new Program().Run();
		}
	}
}