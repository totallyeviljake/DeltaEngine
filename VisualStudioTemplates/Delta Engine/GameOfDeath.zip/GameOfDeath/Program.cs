using DeltaEngine.Platforms;

namespace $safeprojectname$
{
	internal static class Program
	{
		private static void Main()
		{
			new App().Start<Intro, UI, InputCoordinator>();
		}
	}
}