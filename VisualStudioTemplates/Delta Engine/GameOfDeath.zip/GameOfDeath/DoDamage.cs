using System.Collections.Generic;
using System.Linq;
using DeltaEngine.Core;
using DeltaEngine.Entities;
using DeltaEngine.Rendering;
using $safeprojectname$.Items;

namespace $safeprojectname$
{
	public class DoDamage : EntityHandler
	{
		public override void Handle(List<Entity> entities)
		{
			foreach (var itemEffect in entities.OfType<ItemEffect>())
				if (itemEffect.Visibility == Visibility.Show && 
					Time.Current.CheckEvery(itemEffect.DamageInterval))
					itemEffect.DoDamage();
		}

		public override EntityHandlerPriority Priority
		{
			get
			{
				return EntityHandlerPriority.First;
			}
		}
	}
}