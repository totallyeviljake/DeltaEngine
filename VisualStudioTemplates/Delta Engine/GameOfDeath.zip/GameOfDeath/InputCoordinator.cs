using DeltaEngine.Input;
using DeltaEngine.Platforms;

namespace $safeprojectname$
{
	public class InputCoordinator
	{
		public InputCoordinator(Window window, InputCommands input, GameCoordinator gameCoordinator)
		{
			window.ShowCursor = false;
			window.Title = "Game Of Death - Kill rabbits before they occupy more than 75% of the world!";
			input.Add(Key.Escape, key => window.Dispose());
			gameCoordinator.RespondToInput(input);
		}
	}
}