using System;

namespace $safeprojectname$
{
	public class Damage
	{
		public float Interval
		{
			get;
			set;
		}

		public Action DoDamage
		{
			get;
			set;
		}
	}
}