using System;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyProduct("$projectname$")]
[assembly: AssemblyTitle("$projectname$")]
[assembly: AssemblyDescription("Delta Engine Game $projectname$")]
[assembly: AssemblyCompany("Benjamin Nitschke")]
[assembly: AssemblyCopyright("Copyright © Benjamin Nitschke 2013")]
[assembly: ComVisible(false)]
[assembly: CLSCompliant(true)]
[assembly: Guid("$guid1$")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: InternalsVisibleTo("GameOfDeath.Tests")]