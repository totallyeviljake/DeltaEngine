using DeltaEngine.Content;
using DeltaEngine.Graphics;
using DeltaEngine.Multimedia;

namespace $safeprojectname$.Items
{
	public class Toxic : Item
	{
		public Toxic() : base(ContentLoader.Load<Image>("Toxic"), 
			ContentLoader.Load<Image>("ToxicCloud"), ContentLoader.Load<Sound>("ToxicEffect"))
		{
		}

		protected override float ImpactSize
		{
			get
			{
				return 0.15f;
			}
		}

		protected override float ImpactTime
		{
			get
			{
				return 5.0f;
			}
		}

		protected override float Damage
		{
			get
			{
				return 5;
			}
		}

		protected override float DamageInterval
		{
			get
			{
				return 0.1f;
			}
		}

		public override int Cost
		{
			get
			{
				return 20;
			}
		}
	}
}