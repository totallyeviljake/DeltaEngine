using DeltaEngine.Content;
using DeltaEngine.Graphics;
using DeltaEngine.Multimedia;

namespace $safeprojectname$.Items
{
	public class Atomic : Item
	{
		public Atomic(ContentLoader content) : base(content.Load<Image>("Atomic"), 
			content.Load<Image>("RingExplosion"), content.Load<Sound>("AtomicExplosion"))
		{
		}

		protected override float ImpactSize
		{
			get
			{
				return 0.175f;
			}
		}

		protected override float ImpactTime
		{
			get
			{
				return 1.0f;
			}
		}

		protected override float Damage
		{
			get
			{
				return 150;
			}
		}

		protected override float DamageInterval
		{
			get
			{
				return 0.5f;
			}
		}

		public override int Cost
		{
			get
			{
				return 50;
			}
		}
	}
}