using DeltaEngine.Datatypes;
using DeltaEngine.Graphics;
using DeltaEngine.Rendering;
using DeltaEngine.Rendering.Sprites;

namespace $safeprojectname$
{
	public class DeadRabbit : Sprite
	{
		public DeadRabbit(Image image, Rectangle drawArea) : base(image, drawArea)
		{
			Add<FinalTransition>().Add(new Transition.Duration(DeadRabbitDuration)).Add(new 
				Transition.FadingColor(Color));
		}

		private const int DeadRabbitDuration = 5;
	}
}