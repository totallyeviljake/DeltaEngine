namespace DeltaEngine.Editor.$safeprojectname$
{
	public class DesignButton
	{
		public MyButton Button
		{
			get { return new MyButton(); }
		}
	}
}