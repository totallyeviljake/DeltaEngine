using DeltaEngine.Editor.Common;

namespace DeltaEngine.Editor.$safeprojectname$
{
	/// <summary>
	/// Code-behind of $safeprojectname$View.xaml
	/// </summary>
	public partial class $safeprojectname$View : EditorPluginView
	{
		public $safeprojectname$View()
		{
			InitializeComponent();
			Loaded += (sender, args) => Init();
		}

		public $safeprojectname$View(Service service)
			: this() {}

		private void Init()
		{
			if (DataContext is $safeprojectname$ViewModel)
				return;

			DataContext = new $safeprojectname$ViewModel();
		}

		public string ShortName
		{
			get { return "$safeprojectname$"; }
		}

		public string Icon
		{
			get { return "Icons/New.png"; }
		}

		public EditorPluginCategory Category
		{
			get { return EditorPluginCategory.GettingStarted; }
		}

		public int Priority
		{
			get { return 1; }
		}
	}
}