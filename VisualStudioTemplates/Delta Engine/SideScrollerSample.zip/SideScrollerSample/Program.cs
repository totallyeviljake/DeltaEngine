using DeltaEngine.Platforms;

namespace $safeprojectname$
{
	internal static class Program
	{
		public static void Main()
		{
			var app = new App();
			app.Start<SideScrollerGame>();
		}
	}
}