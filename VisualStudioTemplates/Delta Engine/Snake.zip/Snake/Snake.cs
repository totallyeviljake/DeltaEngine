using DeltaEngine.Core;
using DeltaEngine.Datatypes;
using DeltaEngine.Entities;
using DeltaEngine.Rendering;

namespace $safeprojectname$
{
	public class Snake : Entity2D
	{
		public Snake(int gridSize) : base(Rectangle.Zero)
		{
			Add(new Body(gridSize));
			Start<SnakeHandler>();
		}

		public void Dispose()
		{
			var body = Get<Body>();
			foreach (var bodyPart in body.BodyParts)
				bodyPart.IsActive = false;

			Get<Body>().BodyParts.Clear();
			Remove<Body>();
			Stop<SnakeHandler>();
		}
		internal class SnakeHandler : Behavior2D
		{
			public override void Handle(Entity2D entity)
			{
				if (!Time.Current.CheckEvery(0.15f))
					return;

				var body = entity.Get<Body>();
				body.MoveBody();
				body.CheckSnakeCollidesWithChunk();
				body.CheckSnakeCollisionWithBorderOrItself();
			}

			public override Priority Priority
			{
				get
				{
					return Priority.Normal;
				}
			}
		}
	}
}