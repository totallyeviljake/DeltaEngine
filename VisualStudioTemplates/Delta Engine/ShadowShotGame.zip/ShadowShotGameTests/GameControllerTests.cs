using DeltaEngine.Content;
using DeltaEngine.Datatypes;
using DeltaEngine.Input;
using DeltaEngine.Platforms.All;
using DeltaEngine.Platforms.Tests;
using DeltaEngine.Rendering.ScreenSpaces;
using NUnit.Framework;
using ShadowShotGame;

namespace $safeprojectname$
{
	public class GameControllerTests : TestWithAllFrameworks
	{
	}
}