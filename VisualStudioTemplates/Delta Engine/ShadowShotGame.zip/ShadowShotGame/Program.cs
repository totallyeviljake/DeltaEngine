using DeltaEngine.Platforms;

namespace $safeprojectname$
{
	public class Program
	{
		public static void Main()
		{
			new App().Start<Game>();
		}
	}
}