namespace $safeprojectname$
{
	public enum RenderLayer
	{
		Background,
		GameLogo,
		Button
	}
}