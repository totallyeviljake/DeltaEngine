namespace DeltaEngine.Editor.$safeprojectname$
{
	/// <summary>
	/// Code-behind of $safeprojectname$View.xaml
	/// </summary>
	public partial class $safeprojectname$View
	{
		public $safeprojectname$View()
			: this(new $safeprojectname$ViewModel()) {}

		public $safeprojectname$View($safeprojectname$ViewModel viewModel)
		{
			InitializeComponent();
			DataContext = viewModel;
		}
	}
}