namespace DeltaEngine.Editor.$safeprojectname$
{
	public class MyButton
	{
		public MyButton()
		{
			Text = "Click Me";
		}

		public string Text { get; set; }
	}
}