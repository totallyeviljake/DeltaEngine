using System.Windows.Input;
using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;

namespace DeltaEngine.Editor.$safeprojectname$
{
	public class $safeprojectname$ViewModel : ViewModelBase
	{
		public $safeprojectname$ViewModel()
		{
			ClickCommand = new RelayCommand(Click);
		}

		public ICommand ClickCommand { get; private set; }

		private void Click()
		{
			button.Text = "Clicked";
			RaisePropertyChanged("Button");
		}

		private readonly MyButton button = new MyButton();

		public MyButton Button
		{
			get { return button; }
		}
	}
}