using System;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Windows;

[assembly: AssemblyTitle("$projectname$")]
[assembly: AssemblyDescription("Delta Engine $projectname$")]
[assembly: AssemblyCompany("Delta Engine")]
[assembly: AssemblyProduct("$projectname$")]
[assembly: AssemblyCopyright("Copyright © Delta Engine 2013")]
[assembly: ComVisible(false)]
[assembly: CLSCompliant(true)]
[assembly: Guid("$guid1$")]
[assembly: AssemblyVersion("0.9.7.2")]
[assembly: AssemblyFileVersion("0.9.7.2")]
[assembly:
	ThemeInfo(ResourceDictionaryLocation.None, ResourceDictionaryLocation.SourceAssembly)]